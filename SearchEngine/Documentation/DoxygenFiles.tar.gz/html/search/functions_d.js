var searchData=
[
  ['updatefreq',['updateFreq',['../classEntryInterface.html#a3ecf28df6b126942c3ff5383c00b42fd',1,'EntryInterface']]]
];
