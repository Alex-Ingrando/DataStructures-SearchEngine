var searchData=
[
  ['queryprocessor',['QueryProcessor',['../classQueryProcessor.html',1,'']]]
];
