var searchData=
[
  ['pluralise',['pluralise',['../structCatch_1_1pluralise.html',1,'Catch']]],
  ['porter2_5fstemmer_2ecpp',['porter2_stemmer.cpp',['../porter2__stemmer_8cpp.html',1,'']]],
  ['porter2_5fstemmer_2eh',['porter2_stemmer.h',['../porter2__stemmer_8h.html',1,'']]],
  ['preorder',['preOrder',['../classAVLIndex.html#a6ce94ce281e32459b4174a6b5ca9a9a0',1,'AVLIndex']]],
  ['ptr',['Ptr',['../classCatch_1_1Ptr.html',1,'Catch']]],
  ['ptr_3c_20catch_3a_3aitestcase_20_3e',['Ptr&lt; Catch::ITestCase &gt;',['../classCatch_1_1Ptr.html',1,'Catch']]]
];
