var searchData=
[
  ['getamount',['getAmount',['../classEntryInterface.html#a7caad5ed0d700974c9a4cf889cf51b65',1,'EntryInterface']]],
  ['getdata',['getData',['../classHashIndex.html#a5e6a2ee4a42577d655975b4b968ac58f',1,'HashIndex']]],
  ['getdocument',['getDocument',['../classIndexHandler.html#a9b7ce13a0acdc2d7c4fa03b03e0187c8',1,'IndexHandler']]],
  ['getfreq',['getFreq',['../classEntryInterface.html#a8369536c988454fb3bf2f50b2ae71e3d',1,'EntryInterface']]],
  ['getname',['getName',['../classEntryInterface.html#a188d06c8dab2f4d9f276ca8b2536a9f2',1,'EntryInterface']]],
  ['getsize',['getSize',['../classHashIndex.html#a34de2266fba8005b69bcfc52ad5a7964',1,'HashIndex']]],
  ['getspecific',['getSpecific',['../classEntryInterface.html#a964a47f4237bac9dd3798024c3687d78',1,'EntryInterface']]],
  ['getstatistics',['getStatistics',['../classDocumentParser.html#a656422cf726346bc743d2ddffd13ae31',1,'DocumentParser::getStatistics()'],['../classIndexHandler.html#ae048ac4b2d81b6f6e867537881287c72',1,'IndexHandler::getStatistics()']]]
];
