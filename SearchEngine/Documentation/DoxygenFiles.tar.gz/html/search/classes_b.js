var searchData=
[
  ['pluralise',['pluralise',['../structCatch_1_1pluralise.html',1,'Catch']]],
  ['ptr',['Ptr',['../classCatch_1_1Ptr.html',1,'Catch']]],
  ['ptr_3c_20catch_3a_3aitestcase_20_3e',['Ptr&lt; Catch::ITestCase &gt;',['../classCatch_1_1Ptr.html',1,'Catch']]]
];
