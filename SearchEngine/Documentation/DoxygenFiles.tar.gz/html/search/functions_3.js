var searchData=
[
  ['entryinterface',['EntryInterface',['../classEntryInterface.html#a4ca0cbe037383e30ed8ff586bcbb1925',1,'EntryInterface::EntryInterface(const string &amp;word)'],['../classEntryInterface.html#a0d8ac403fa60f0d047601a528124aeac',1,'EntryInterface::EntryInterface(const string &amp;word, const string &amp;doc)'],['../classEntryInterface.html#a55a5d6457f4d896bf835ef6c398afe93',1,'EntryInterface::EntryInterface(const string &amp;word, pair&lt; string, int &gt; location)'],['../classEntryInterface.html#abaea082195780c85f3ba5413d3136f3a',1,'EntryInterface::EntryInterface(const string &amp;word, vector&lt; pair&lt; string, int &gt;&gt; location)']]]
];
