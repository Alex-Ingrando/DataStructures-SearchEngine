var searchData=
[
  ['deleteindex',['deleteIndex',['../classAVLIndex.html#a0dddf316089c443b93d92111db475388',1,'AVLIndex::deleteIndex()'],['../classHashIndex.html#ab826347c37b7c1c6c10b16bf81869ff9',1,'HashIndex::deleteIndex()'],['../classIndexHandler.html#a59e75fe34d121a971363e5ca66cab47d',1,'IndexHandler::deleteIndex()']]]
];
