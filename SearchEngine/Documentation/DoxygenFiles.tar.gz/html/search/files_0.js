var searchData=
[
  ['porter2_5fstemmer_2ecpp',['porter2_stemmer.cpp',['../porter2__stemmer_8cpp.html',1,'']]],
  ['porter2_5fstemmer_2eh',['porter2_stemmer.h',['../porter2__stemmer_8h.html',1,'']]]
];
