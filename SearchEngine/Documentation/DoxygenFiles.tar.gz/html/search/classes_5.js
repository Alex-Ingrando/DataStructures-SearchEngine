var searchData=
[
  ['falsetype',['FalseType',['../structCatch_1_1Detail_1_1FalseType.html',1,'Catch::Detail']]]
];
