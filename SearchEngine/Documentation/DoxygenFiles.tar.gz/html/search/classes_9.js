var searchData=
[
  ['nameanddesc',['NameAndDesc',['../structCatch_1_1NameAndDesc.html',1,'Catch']]],
  ['noncopyable',['NonCopyable',['../classCatch_1_1NonCopyable.html',1,'Catch']]],
  ['notimplementedexception',['NotImplementedException',['../classCatch_1_1NotImplementedException.html',1,'Catch']]]
];
